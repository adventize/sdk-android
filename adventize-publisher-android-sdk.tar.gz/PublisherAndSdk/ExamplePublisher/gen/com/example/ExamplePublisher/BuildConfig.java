/** Automatically generated file. DO NOT MODIFY */
package com.example.ExamplePublisher;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}