package com.example.ExamplePublisher;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.adventize.publisher.main.Publisher;
import com.adventize.publisher.publisher.AskFetchCallback;

public class MyActivity extends Activity implements View.OnClickListener, AskFetchCallback {

    private Button btnActionLaunchOfferwall;
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        btnActionLaunchOfferwall = (Button) findViewById(R.id.btnActionLaunchOfferwall);
        btnActionLaunchOfferwall.setOnClickListener(this);

        //call this to report about starting session
        Publisher.startSession(getApplicationContext());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnActionLaunchOfferwall:
                //tell sdk to ask for offerwall,and send first argument as object callback which will be called, when
                // offerwall finished downloading
                Publisher.askFetch(this, "5271", this);
                //if you do not want ot use callback, just call Publisher.callOfferwall("5271",this); instead.
                break;
            default:
                break;
        }
    }

    @Override
    public void finish()
    {
        //call this to report about stopping session
        Publisher.stopSession();
        super.finish();
    }

    /**
     * Use these method to get callback report, when offerwall finished loading
     * @param ok true - when offerwal is ok.
     *           false - when it is empty(nothing to show)
     */
    @Override
    public void fetchFinished(boolean ok) {
        if(ok)
        {//call offerwall, when it finished loading and everything is ok.
            Publisher.callOfferwall("5271",this);
        }
    }
}
