package com.example.ExamplePublisher;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.adventize.advertizer.Advertizer;
import com.adventize.publisher.main.AdventizePublisher;

public class MyActivity extends Activity implements View.OnClickListener{

    private Button btnActionLaunchOfferwall;
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        btnActionLaunchOfferwall = (Button) findViewById(R.id.btnActionLaunchOfferwall);
        btnActionLaunchOfferwall.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnActionLaunchOfferwall:
                startActivity(AdventizePublisher.getOfferwall("5271", getApplicationContext()));
                break;
            default:
                break;
        }
    }

    @Override
    public void onDestroy()
    {
        Advertizer.stopSession();
        super.onDestroy();
    }
}
