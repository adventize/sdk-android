package com.adventize.pubdemo;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.adventize.banner.Banner;
import com.adventize.banner.BannerEntity;
import com.adventize.banner.CloseListener;
import com.adventize.offers.OfferWallItem;
import com.adventize.offers.SendImpressionsCallback;
import com.adventize.sdk.Publisher;
import com.adventize.sdk.Response;
import com.adventize.sdk.ResponseStatus;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.List;

public class OfferWallActivity extends Activity implements SendImpressionsCallback {

    private Dialog bannerDialog;
    private static Publisher sAdventize;

    public Publisher getAdventize(final Context context) {
        if (sAdventize == null) {
            String yourAppId = "7026";
            String yourSecret = "some_secret";
            int yourGoogleAnalyticsVersion = 3; //Set version of google analytics lib, which you prefer to use
            sAdventize = new Publisher(context, yourAppId, yourSecret, yourGoogleAnalyticsVersion) {
                @Override
                protected RequestQueue getRequestQueue() {
                    return Volley.newRequestQueue(context);
                }
            };
        }
        return sAdventize;
    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        getAdventize(this).setUserId("Vasya");
        getAdventize(this).setUserRate(55);
        getAdventize(this).startSession();

        askForFetch();
        askForBanner();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (bannerDialog != null)
            bannerDialog.dismiss();
    }

    @Override
    protected void onDestroy() {
        if (bannerDialog != null)
            bannerDialog.dismiss();

        if (isFinishing()) {
            getAdventize(this).stopSession();   //report stop session on destroy if finishing
        }
        super.onDestroy();
    }

    @Override
    public void onSendImpressionsResult(boolean ok) {
        if (ok)
            Log.i("Example", "Impressions were send");
        else
            Log.w("Example", "Impressions weren't send");
    }

    private void onBannersResponse(final ResponseStatus status, final BannerEntity[] result) {
        if (status == ResponseStatus.OK) {
            if (result.length == 0) {
                Log.w("Example", "Empty banner list!");
                return;
            }
            final Banner banner = new Banner(this, result[0]); //Create first one

            bannerDialog = new Dialog(this) {   //Create dialog window and insert banner to it (example usage)
                @Override
                protected void onCreate(final Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    this.setContentView(R.layout.banner_dialog);

                    banner.setCloseListener(new CloseListener() {   //Set close listener callback to banner
                        @Override
                        public void onCloseBanner(final Banner banner) {
                            dismiss();
                        }
                    });

                    ViewGroup l = (ViewGroup) findViewById(R.id.bannerLayout);
                    l.addView(banner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                }
            };
            try {
                bannerDialog.show();    //show dialog with banner
            } catch (Exception e) {
                Log.e("Example", "Try to show banner on non-existent activity");
            }
        } else
            Log.w("Example", "Error occurred!");
    }

    private void onFetchResponse(final ResponseStatus status, final OfferWallItem[] result) {
        if (status == ResponseStatus.OK) {
            if (result.length == 0) {
                Log.w("Example", "Empty offerwall!");
                return;
            }

            List<Long> impressions = new ArrayList<Long>();

            //show all items of offerwall, remember impressions
            for (OfferWallItem item : result) {
                Log.d("Example", String.format("Name %s\n Desc %s\n Cost %s\n Payout %s\n Icon %s\n Click %s\n\n\n",
                        item.getName(), item.getDesc(), item.getCost(), item.getPayout(), item.getIconURL(), item.getUrl()));
                impressions.add(item.getCampaignId());  //add every shown ad item to impressions
            }

            //send impressions
            getAdventize(this).sendImpressions(impressions, this);

            //make click in the first item, if exists
            OfferWallItem clickMe = result[0];
            final Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(clickMe.getUrl()));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } else
            Log.w("Example", "Error occurred!");
    }

    private void askForBanner() {
        getAdventize(this).requestBanners(new Response<BannerEntity[]>() {
            @Override
            public void onResponse(ResponseStatus responseStatus, BannerEntity[] bannerEntities) {
                onBannersResponse(responseStatus, bannerEntities);
            }
        }, "MainMenu.ABC", "banner", "MainMenu.B");
    }

    private void askForFetch() {
        getAdventize(this).requestOffers(new Response<OfferWallItem[]>() {
            @Override
            public void onResponse(final ResponseStatus status, final OfferWallItem[] result) {
                onFetchResponse(status, result);
            }
        });
    }
}
