package com.adventize.pubdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.adventize.utils.AdventizeSDK;

public class OfferWallActivity extends Activity implements View.OnClickListener {

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        final Button btnActionLaunchOfferwall = (Button) findViewById(R.id.btnActionLaunchOfferwall);
        btnActionLaunchOfferwall.setOnClickListener(this);

        AdventizeSDK.startSession(getApplicationContext(), "5271");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AdventizeSDK.stopSession();
    }

    @Override
    public void onClick(final View v) {
        switch (v.getId()) {
            case R.id.btnActionLaunchOfferwall:
                AdventizeSDK.showOfferWallWindow(this);
                break;
            default:
                break;
        }
    }
}
