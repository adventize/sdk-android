package com.adventize.pubdemo;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.adventize.banner.Banner;
import com.adventize.banner.CloseListener;
import com.adventize.banner.CustomCallback;
import com.adventize.main.AskBannerCallback;
import com.adventize.main.OfferWallAPI;
import com.adventize.main.Publisher;
import com.adventize.publisherLight.AskFetchCallback;
import com.adventize.publisherLight.OfferWallItem;
import com.adventize.publisherLight.SendImpressionsCallback;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public class OfferWallActivity extends Activity implements AskBannerCallback, AskFetchCallback, SendImpressionsCallback {

    private final String bannerToAsk = "MainMenu.ABC";
    private Dialog bannerDialog;

    private CustomCallback callback;

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        Publisher.enableLog(true);
        Publisher.setUserID("Vasya");
        Publisher.setUserRate(55);

        Publisher.startSession(getApplicationContext(), "5933");

        callback = new CustomCallback(new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                exampleCustomCallback(callback);
                return null;
            }
        });

        Publisher.askFetch(this, getApplicationContext());

        Publisher.addCallback("goToShop", callback);

        Publisher.askBanners(this, this, bannerToAsk, "banner");
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (bannerDialog != null)
            bannerDialog.dismiss();

        if (isFinishing()) {
            Publisher.invalidateBanners(bannerToAsk);
        }
    }

    public void exampleCustomCallback(CustomCallback self) {
        Map<String, String> params = self.getParams();
        if (params != null)
            Log.d("Example", "got callback with params : " + params.toString());
        else
            Log.d("Example", "got callback without params.");
    }

    @Override
    protected void onDestroy() {
        if (bannerDialog != null)
            bannerDialog.dismiss();
        super.onDestroy();
        Publisher.stopSession();
    }

    @Override
    public void onBannersLoaded(@Nonnull final List<Banner> banners) {
        if (banners.isEmpty()) {
            return;
        }
        final Banner banner = banners.get(0);

        bannerDialog = new Dialog(this) {
            @Override
            protected void onCreate(final Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                this.setContentView(R.layout.banner_dialog);


                banner.setCloseListener(new CloseListener() {
                    @Override
                    public void onCloseBanner(final Banner banner) {
                        dismiss();
                    }
                });

                ViewGroup l = (ViewGroup) findViewById(R.id.bannerLayout);
                l.addView(banner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
        };
        try {
            bannerDialog.show();
        } catch (Exception e) {
            Log.e("Example", "Try to show banner on non-existent activity");
        }
    }

    @Override
    public void offerWallFinished(@Nullable List<OfferWallItem> offerWall) {

        if (offerWall == null || offerWall.isEmpty()) {
            Log.w("Example", "Empt offerwall!");
            return;
        }

        List<Long> impressions = new ArrayList<Long>();

        //show all items of offerwall, remember impressions
        for (OfferWallItem item : offerWall) {
            Log.d("Example", String.format("Name %s\n Desc %s\n Cost %s\n Payout %s\n Icon %s\n Click %s\n\n\n",
                    item.getName(), item.getDesc(), item.getCost(), item.getPayout(), item.getIconURL(), item.getUrl()));
            impressions.add(item.getCampaignId());
        }

        //send impressions
        OfferWallAPI.sendImpressions(impressions, getApplicationContext(), this);

        //make click in the first item, if exists
        if (!offerWall.isEmpty()) {
            OfferWallItem clickMe = offerWall.get(0);
            OfferWallAPI.sendClick(clickMe.getUrl(), this);
        }

        //clear offerwall no to show same again
        Publisher.invalidateOffer();
    }

    @Override
    public void onSendImpressionsResult(boolean ok) {
        if (ok)
            Log.i("Example", "Impressions were send");
        else
            Log.w("Example", "Impressions weren't send");
    }
}
