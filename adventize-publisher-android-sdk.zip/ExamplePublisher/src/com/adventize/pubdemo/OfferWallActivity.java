package com.adventize.pubdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.adventize.utils.AdventizeSDK;

public class OfferWallActivity extends Activity implements View.OnClickListener{

    private Button btnActionLaunchOfferwall;

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        btnActionLaunchOfferwall = (Button) findViewById(R.id.btnActionLaunchOfferwall);
        btnActionLaunchOfferwall.setOnClickListener(this);

        AdventizeSDK.startSession(getApplicationContext(), "5271");

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AdventizeSDK.stopSession();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnActionLaunchOfferwall:
                AdventizeSDK.showOfferWallWindow(this);
                break;
            default:
                break;
        }
    }
}
