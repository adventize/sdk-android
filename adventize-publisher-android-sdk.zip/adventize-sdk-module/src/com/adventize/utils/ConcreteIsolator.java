package com.adventize.utils;

import com.adventize.publisher.R;

public class ConcreteIsolator {
    public static void init() {
        Isolator.drawable_app_default = R.drawable.app_default;
        Isolator.ID_ADVENTIZE_OFFER_WALL = R.id.adventize_offer_wall;
        Isolator.ID_Animator = R.id.Animator;
        Isolator.ID_app_icon = R.id.app_icon;
        Isolator.ID_desc = R.id.desc;
        Isolator.ID_ErrorMessageText = R.id.ErrorMessageText;
        Isolator.ID_gift_desc = R.id.gift_desc;
        Isolator.ID_ListView = R.id.ListView;
        Isolator.ID_name = R.id.name;
        Isolator.ID_price = R.id.price;
        Isolator.ID_REFRESH = R.id.refresh;
        Isolator.LAYOUT_ADVENTIZE = R.layout.adventize;
        Isolator.LAYOUT_adventize_offer_wall_list_item = R.layout.adventize_offer_wall_list_item;
        Isolator.MENU_OFFER_WALL = R.menu.adventize_menu;
        Isolator.STR_Loading = R.string.Loading;
        Isolator.STR_NetworkUnavailable = R.string.NetworkUnavailable;
        Isolator.STR_NothingFound = R.string.NothingFound;
    }

}
