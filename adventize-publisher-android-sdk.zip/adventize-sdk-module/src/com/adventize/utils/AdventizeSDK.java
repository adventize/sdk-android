package com.adventize.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.adventize.gui.MainActivity;
import com.adventize.main.Publisher;

/**
 * Created with IntelliJ IDEA.
 * User: tihon
 * Date: 28.03.13
 * Time: 14:13
 * To change this template use File | Settings | File Templates.
 */
public class AdventizeSDK {

    public static void startSession(Context context, String appId)
    {
        Publisher.startSession(context,appId);
    }

    public static void showOfferWallWindow(Activity activity)
    {
        ConcreteIsolator.init();
        Intent adventizeIntent = new Intent(activity, MainActivity.class);
        activity.startActivity(adventizeIntent);
    }

    public static void stopSession()
    {
        Publisher.stopSession();
    }
}
