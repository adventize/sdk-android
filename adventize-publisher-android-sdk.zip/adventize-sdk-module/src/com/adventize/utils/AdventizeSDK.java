package com.adventize.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.adventize.gui.MainActivity;
import com.adventize.main.Publisher;

public class AdventizeSDK {

    public static void startSession(final Context context, final String appId) {
        Publisher.startSession(context, appId);
        ConcreteIsolator.init();
    }

    public static void showOfferWallWindow(final Activity activity) {
        final Intent adventizeIntent = new Intent(activity, MainActivity.class);
        activity.startActivity(adventizeIntent);
    }

    public static void stopSession() {
        Publisher.stopSession();
    }

}
