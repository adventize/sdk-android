package com.adventize.addemo;

import android.app.Activity;
import android.os.Bundle;
import com.adventize.advertiser.Advertiser;

public class MyActivity extends Activity {
    private static final String ADVENTIZE_APP_ID = "5271";

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Advertiser.startSession(this, ADVENTIZE_APP_ID, "jdjdjdjjdjdjdjdjjdjdjd");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (isFinishing()) {
            Advertiser.stopSession();
        }
    }
}
