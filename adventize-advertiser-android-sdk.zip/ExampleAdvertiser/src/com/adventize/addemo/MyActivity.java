package com.adventize.addemo;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.adventize.sdk.Advertiser;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class MyActivity extends Activity {
    private static Advertiser sAdventize;

    public Advertiser getAdventize(final Context context) {
        if (sAdventize == null) {
            String yourAppId = "5933";
            String yourSecret = "some_secret";
            int yourGoogleAnalyticsVersion = 2; //Set version of google analytics lib, which you prefer to use
            sAdventize = new Advertiser(context, yourAppId, yourSecret, yourGoogleAnalyticsVersion) {
                @Override
                protected RequestQueue getRequestQueue() {
                    return Volley.newRequestQueue(context);
                }
            };
        }

        return sAdventize;
    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        getAdventize(this).startSession();

        getAdventize(this).setUserId("Vasya");
        getAdventize(this).sendAction("reached80level");
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) {
            getAdventize(this).stopSession();   //report stop session on destroy if finishing
        }
        super.onDestroy();
    }
}
