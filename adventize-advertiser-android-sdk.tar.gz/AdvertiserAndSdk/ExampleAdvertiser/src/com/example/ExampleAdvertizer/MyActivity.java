package com.example.ExampleAdvertizer;

import android.app.Activity;
import android.os.Bundle;
import com.adventize.advertizer.Advertizer;

public class MyActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        //set appId and start session in parallel thread.
        Advertizer.startSession(this, "5959", "your secret");
    }

    @Override
    public void onDestroy()
    {
        Advertizer.stopSession();
        super.onDestroy();
    }
}
